package network;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class BNode {
	private ArrayList<BNode> parents;
	private HashMap<String,Float> probability;
	private String name;
	
	public BNode(String name){
		parents = new ArrayList<BNode>();
		probability = new HashMap<String,Float>();
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ArrayList<BNode> getParents() {
		return parents;
	}
	
	public BNode getParentByName(String name) {
		if(!this.hasParents())
			return null;
		name = name.replaceAll("[+-]", "");
		for(int i = 0; i < this.parents.size(); i++) { 
			if(this.parents.get(i).getName().equals(name)){
				return this.parents.get(i);
			}
		}
		return null;
	}

	public void setParents(ArrayList<BNode> parents) {
		this.parents = parents;
	}

	public float getProbability(String key){
		String keyProb;
		if(!hasParents()){
			if(key.charAt(0)=='-'){
				key = key.substring(1);
				return round(1-this.probability.get(key),2).floatValue();
			}
			return this.probability.get(key);
		}else{
			String[] query = key.split("\\|");                 //Split accepts a string in regex format (that's why we use double back slash for the character |)
			String[] evidenceNodes;
			String auxEvidence;
			BNode parentNode;
			float probSum = 0;
			
			
			Set<String> keySet = this.probability.keySet();     //Here I am retrieving probability keys, EX:{+Dry,-Sick},{-Dry,-Sick}
			Iterator<String> keySetIterator = keySet.iterator();
			
			while (keySetIterator.hasNext()) {
			   keyProb = keySetIterator.next();   
			   
			   if(keyProb.contains(query[1])){                  //First we validate if probability applies to request, ex:  {+Dry,-Sick} contains +Dry
				   
				   if(keyProb.equals(key))
					   return this.probability.get(key);
				   												//We continue running this probability in case request exactly matches what we are looking for in the probability Table
				   evidenceNodes = query[1].split(",");
				   probSum += this.probability.get(keyProb);
				   
				   for(int i=0; i<evidenceNodes.length; i++){
					   parentNode = this.getParentByName(evidenceNodes[i]);
					   probSum *= parentNode.getProbability(evidenceNodes[i]);
				   }
				   
			   }
			   //System.out.println(keyProb + "=" + this.probability.get(keyProb));
			}
			return probSum;
		}
	}
	
	public static BigDecimal round(float d, int decimalPlace) {
        BigDecimal bd = new BigDecimal(Float.toString(d));
        bd = bd.setScale(decimalPlace, BigDecimal.ROUND_HALF_UP);       
        return bd;
    }
	
	public void putProbability(String key, Float probability){
		this.probability.put(key, probability);
	}
	
	public void addParent(BNode bNode){
		this.parents.add(bNode);
	}
	
	public boolean hasParents(){
		return this.parents.size()>0;
	}
	
	public void printNode(){
		System.out.print("Node: "+getName() + "  Parents: ");
		for(int i = 0; i < this.parents.size(); i++) {   
		    System.out.print(this.parents.get(i).getName()+" ");
		} 
		System.out.println("");
		Set<String> keySet = this.probability.keySet();
		Iterator<String> keySetIterator = keySet.iterator();
		//System.out.println("Probabilities: ");
		while (keySetIterator.hasNext()) {
		   String key = keySetIterator.next();
		   System.out.println(key + "=" + this.probability.get(key));
		}
		System.out.println("");
	}

}
